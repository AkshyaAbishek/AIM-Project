# 🎮 AIM - Actuarial Input Mapper

A modern, professional actuarial data processing application with an intuitive GUI interface and comprehensive learning materials.

## 🚀 Quick Start

### For Beginners (New to Python)
```bash
# 1. Start learning Python
cd tutorials/python_basics
python PYTHON_TUTORIAL_INTERACTIVE.py

# 2. Understand this project  
cd ../project_examples
python YOUR_FILE_EXPLAINED.py

# 3. Run the main application
cd ../../scripts
start.bat
```

### For Experienced Users
```bash
# Quick launch
scripts/start.bat

# Or with full setup
scripts/setup_and_run.bat
```

## 📁 Project Organization

```
AIM/
├── 🎯 example.py                    # Main GUI application
├── 📋 requirements.txt              # Python dependencies
├── 📊 aim_data.db                   # SQLite database
│
├── 📂 src/                          # Core application code
├── 📂 common/                       # Shared utilities  
├── 📂 tutorials/                    # Python learning materials
├── 📂 documentation/                # User guides and docs
├── 📂 scripts/                      # Launch scripts
├── 📂 data/                         # Sample data
├── 📂 tests/                        # Test files
└── 📂 utils/                        # Utility scripts
```

## 🎯 What This Project Does

The AIM (Actuarial Input Mapper) processes insurance and actuarial data by:

1. **📥 Input Processing**: Accepts data from various sources (JSON, Excel, web forms)
2. **🔄 Data Transformation**: Converts messy data into standardized actuarial formats
3. **✅ Validation**: Ensures data quality and completeness
4. **📊 Excel Integration**: Creates professional Excel templates and exports
5. **💾 Data Management**: Stores and manages data with duplicate prevention
6. **🖥️ Modern GUI**: User-friendly interface with modern styling

## 🎓 Learning Path

### 📚 For Python Beginners
1. **Python Basics**: `tutorials/python_basics/PYTHON_TUTORIAL_INTERACTIVE.py`
2. **Complete Guide**: `tutorials/python_basics/PYTHON_BASICS_EXPLAINED.py`  
3. **Project Understanding**: `tutorials/project_examples/YOUR_FILE_EXPLAINED.py`

### 📖 For Users
1. **Quick Start**: `documentation/guides/QUICK_START.md`
2. **Excel Guide**: `documentation/guides/EXCEL_MAPPING_GUIDE.md`
3. **Troubleshooting**: `documentation/guides/TROUBLESHOOTING_GUIDE.md`

### 🔧 For Developers
1. **Project Structure**: `PROJECT_STRUCTURE_GUIDE.md`
2. **Source Code**: `src/` folder
3. **Shared Utilities**: `common/` folder

## ⚡ Key Features

### 🎨 Modern User Interface
- Clean, professional design
- Scrollable dialogs and forms
- Interactive buttons with hover effects
- Real-time status updates
- Progress indicators for long operations

### 📊 Data Processing
- Supports Life Insurance and Annuity products
- Intelligent field mapping
- Data validation and error checking
- Duplicate prevention
- Comprehensive logging

### 📈 Excel Integration
- Professional Excel template generation
- Field mapping with validation
- Export capabilities
- Summary statistics
- Bulk data loading from Excel

### 💾 Database Features
- SQLite-based data storage
- Automatic duplicate detection
- Search and filter capabilities
- Data persistence across sessions
- Export to various formats

## 🔧 Technical Stack

- **Language**: Python 3.x
- **GUI Framework**: tkinter (built-in)
- **Database**: SQLite
- **Data Processing**: pandas, json
- **Excel Operations**: openpyxl
- **Architecture**: Modular, object-oriented design

## 📋 Prerequisites

```bash
# Install Python 3.x
# Install required packages:
pip install -r requirements.txt
```

## 🚀 Running the Application

### Method 1: Scripts (Recommended)
```bash
# Windows
scripts/start.bat

# Or for full setup
scripts/setup_and_run.bat
```

### Method 2: Direct Python
```bash
python example.py
```

### Method 3: Professional Version
```bash
scripts/launch_aim_pro.bat
```

## 📚 Documentation

- **📖 User Guides**: `documentation/guides/`
- **🎓 Tutorials**: `tutorials/`
- **📋 Project Structure**: `PROJECT_STRUCTURE_GUIDE.md`
- **🔧 Technical Docs**: `src/` and `common/` folders

## 🆘 Need Help?

1. **Python Beginner?** → `tutorials/README.md`
2. **Application Issues?** → `documentation/guides/TROUBLESHOOTING_GUIDE.md`
3. **Excel Problems?** → `documentation/guides/EXCEL_MAPPING_GUIDE.md`
4. **General Questions?** → `documentation/README.md`

## 🎯 Project Goals

- **Professional**: Enterprise-grade actuarial data processing
- **Educational**: Comprehensive Python learning materials
- **User-Friendly**: Intuitive interface for non-technical users
- **Maintainable**: Clean, modular code structure
- **Scalable**: Easy to extend with new features

## 🔄 Recent Improvements

- ✅ Modular code organization
- ✅ Comprehensive Python tutorials
- ✅ Modern UI with enhanced styling
- ✅ Robust error handling
- ✅ Database integration with duplicate prevention
- ✅ Excel template generation
- ✅ Professional documentation structure

---

## 🎉 Get Started Now!

Choose your path:
- **🎓 Learn Python**: `tutorials/python_basics/`
- **🚀 Use the App**: `scripts/start.bat`
- **📖 Read Docs**: `documentation/guides/`
- **🔧 Explore Code**: `src/` and `common/`

*Welcome to professional actuarial data processing with Python!* 🐍✨
