"""Configuration package for managing settings and mappings."""
